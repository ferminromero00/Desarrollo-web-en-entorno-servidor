<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class NavigationController extends AbstractController
{
    private $requestStack;

    public function __construct(RequestStack $requestStack)
    {
        $this->requestStack = $requestStack;
    }

    #[Route('/', name: 'app_navigation')]
    public function index(): Response
    {
        return $this->render('navigation/index.html.twig', [
            'controller_name' => 'NavigationController',
        ]);
    }

    #[Route('/register', name: 'app_register')]
    public function register(Request $request): Response
    {
        if ($request->isMethod('POST')) {
            $client = HttpClient::create();

            try {
                // Registro del usuario
                $response = $client->request(
                    'POST',
                    'http://localhost:8000/api/register',
                    [
                        'json' => [
                            'email' => $request->request->get('email'),
                            'password' => $request->request->get('password')
                        ]
                    ]
                );

                if ($response->getStatusCode() === 200) {
                    $this->addFlash('success', 'Registration successful!');

                    // Autenticación y obtención del token
                    $takeToken = $client->request(
                        'POST',
                        'http://localhost:8000/api/login_check',
                        [
                            'json' => [
                                'username' => $request->request->get('email'),
                                'password' => $request->request->get('password'),
                            ]
                        ]
                    );

                    if ($takeToken->getStatusCode() === 200) {
                        $data = $takeToken->toArray();
                        $token = $data['token'] ?? null;

                        if ($token) {
                            // Guardamos el token en la sesión
                            $this->requestStack->getSession()->set('auth_token', $token);

                            // Petición para obtener los datos del dashboard
                            $dashboardResponse = $client->request(
                                'GET',
                                'http://localhost:8000/api/dashboard',
                                [
                                    'headers' => [
                                        'Authorization' => 'Bearer ' . $token, // Añadido espacio después de Bearer
                                    ]
                                ]
                            );

                            if ($dashboardResponse->getStatusCode() === 200) {
                                $dashBoardData = $dashboardResponse->toArray();
                                $this->addFlash('success', 'Dashboard data success: ' . json_encode($dashBoardData));

                                // Redirigir a la página mostrarRespuesta con los datos del dashboard
                                return $this->redirectToRoute('app_mostrarRespuesta', [
                                    'data' => $dashBoardData // Pasamos los datos como parámetros a la redirección
                                ]);
                            } else {
                                $this->addFlash('error', 'Failed to fetch dashboard data');
                            }
                        }
                    }
                }
            } catch (\Exception $e) {
                $this->addFlash('error', 'Registration failed: ' . $e->getMessage());
            }
        }

        return $this->render('navigation/index.html.twig');
    }

    #[Route('/checkToken', name: 'app_checkToken')]
    public function checkToken(): Response
    {
        $token = $this->requestStack->getSession()->get('auth_token');

        return $this->render('navigation/checkToken.html.twig', [
            'token' => $token
        ]);
    }

    // Ruta para mostrar la respuesta del dashboard
    #[Route('/mostrarRespuesta', name: 'app_mostrarRespuesta')]
    public function mostrarRespuesta(Request $request): Response
    {
        // Obtener los datos pasados a través de la redirección
        $data = $request->query->get('data');

        return $this->render('navigation/mostrarRespuesta.html.twig', [
            'data' => $data
        ]);
    }
}
